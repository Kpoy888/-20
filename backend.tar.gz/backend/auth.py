import hmac
import hashlib
import time
from urllib.parse import parse_qsl
from typing import Optional
from collections import defaultdict

# Простая защита от спама (rate limit)
_rate_limit = defaultdict(list)
RATE_LIMIT_WINDOW = 60  # секунд
RATE_LIMIT_MAX = 10     # запросов в минуту

def check_rate_limit(user_id: int) -> bool:
    now = time.time()
    user_times = _rate_limit[user_id]
    # чистим старые
    _rate_limit[user_id] = [t for t in user_times if now - t < RATE_LIMIT_WINDOW]
    if len(_rate_limit[user_id]) >= RATE_LIMIT_MAX:
        return False
    _rate_limit[user_id].append(now)
    return True

def validate_init_data(init_data: str, bot_token: str) -> Optional[dict]:
    """Строгая проверка подписи initData от Telegram."""
    if not init_data or not bot_token:
        return None
    try:
        parsed = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = parsed.pop("hash", None)
        if not received_hash:
            return None

        # Проверка auth_date (не старше 24 часов)
        auth_date = int(parsed.get("auth_date", 0))
        if time.time() - auth_date > 86400:
            return None

        data_check_string = "\n".join(
            f"{k}={v}" for k, v in sorted(parsed.items())
        )
        secret_key = hmac.new(
            b"WebAppData", bot_token.encode(), hashlib.sha256
        ).digest()
        calculated = hmac.new(
            secret_key, data_check_string.encode(), hashlib.sha256
        ).hexdigest()

        if hmac.compare_digest(calculated, received_hash):
            return parsed
        return None
    except Exception:
        return None
