import asyncio
import os
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import WebAppInfo, InlineKeyboardButton, InlineKeyboardMarkup
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://your-domain.com")
OWNER_TG_ID = int(os.getenv("OWNER_TELEGRAM_ID", "0"))

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

def is_owner(user_id: int) -> bool:
    return user_id == OWNER_TG_ID

@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="Открыть обмен", web_app=WebAppInfo(url=WEBAPP_URL))
    ]])
    await message.answer(
        "Добро пожаловать!\n\n"
        "Этот бот — техническая площадка для безвозмездной передачи Telegram-подарков и USDT "
        "в целях поддержки и развития малого бизнеса.\n\n"
        "Все операции носят характер добровольного дарения. "
        "Перед использованием необходимо принять условия.",
        reply_markup=kb
    )

@dp.message(Command("confirm"))
async def cmd_confirm(message: types.Message):
    if not is_owner(message.from_user.id):
        await message.answer("Доступ запрещён.")
        return
    args = message.text.split()
    if len(args) < 2 or not args[1].isdigit():
        await message.answer("Использование: /confirm <id_сделки>")
        return
    # Здесь можно вызвать API или напрямую менять статус в базе
    await message.answer(f"Сделка #{args[1]} отмечена как подтверждённая (реализуйте вызов API или прямое обновление БД).")

@dp.message(Command("complete"))
async def cmd_complete(message: types.Message):
    if not is_owner(message.from_user.id):
        await message.answer("Доступ запрещён.")
        return
    args = message.text.split()
    if len(args) < 2 or not args[1].isdigit():
        await message.answer("Использование: /complete <id_сделки>")
        return
    await message.answer(f"Сделка #{args[1]} завершена.")

@dp.message(Command("mydeals"))
async def cmd_mydeals(message: types.Message):
    if not is_owner(message.from_user.id):
        await message.answer("Доступ запрещён.")
        return
    await message.answer("Список активных сделок доступен через Mini App или админ-API.")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
