from fastapi import FastAPI, HTTPException, Depends, Request
from pydantic import BaseModel, Field, validator
from sqlalchemy.orm import Session
from dotenv import load_dotenv
import os
from datetime import datetime, timedelta
from auth import validate_init_data, check_rate_limit
from models import SessionLocal, Deal, User, DealLog
from decimal import Decimal

load_dotenv()
app = FastAPI(title="Telegram Escrow API")

BOT_TOKEN = os.getenv("BOT_TOKEN")
COMMISSION = float(os.getenv("COMMISSION_PERCENT", "5.0"))
OWNER_TG_ID = int(os.getenv("OWNER_TELEGRAM_ID", "0"))
OWNER_TG_USERNAME = os.getenv("OWNER_TELEGRAM_USERNAME", "Kpoy88")
OWNER_WALLET = os.getenv("OWNER_WALLET_ADDRESS", "")
OWNER_NETWORK = os.getenv("OWNER_WALLET_NETWORK", "TRC20")
OWNER_COIN = os.getenv("OWNER_WALLET_COIN", "USDT")
OWNER_BYBIT_UID = os.getenv("OWNER_BYBIT_UID", "")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_user_id_from_init(init_data: str) -> int:
    user_data = validate_init_data(init_data, BOT_TOKEN)
    if not user_data:
        raise HTTPException(status_code=401, detail="Invalid or expired initData")
    user_raw = user_data.get("user")
    if isinstance(user_raw, str):
        import json
        try:
            user_raw = json.loads(user_raw)
        except Exception:
            user_raw = {}
    user_id = int(user_raw.get("id") if isinstance(user_raw, dict) else user_data.get("id", 0))
    if not user_id:
        raise HTTPException(status_code=400, detail="No user id")
    if not check_rate_limit(user_id):
        raise HTTPException(status_code=429, detail="Too many requests")
    return user_id

def log_action(db: Session, deal_id: int, action: str, by_user: int):
    db.add(DealLog(deal_id=deal_id, action=action, by_user=by_user))
    db.commit()

class CreateDealRequest(BaseModel):
    init_data: str
    deal_type: str = Field(..., max_length=32)
    give_what: str = Field(..., max_length=200)
    get_what: str = Field(..., max_length=200)
    amount: float = Field(..., gt=0, le=1000000)
    notes: str = Field(None, max_length=500)

class AcceptDealRequest(BaseModel):
    init_data: str
    deal_id: int

class AdminActionRequest(BaseModel):
    init_data: str
    deal_id: int

class AcceptTermsRequest(BaseModel):
    init_data: str

@app.post("/api/accept-terms")
async def accept_terms(req: AcceptTermsRequest, db: Session = Depends(get_db)):
    user_id = get_user_id_from_init(req.init_data)
    user = db.query(User).filter(User.telegram_id == user_id).first()
    if not user:
        user = User(telegram_id=user_id, terms_accepted=1, terms_accepted_at=datetime.utcnow())
        db.add(user)
    else:
        user.terms_accepted = 1
        user.terms_accepted_at = datetime.utcnow()
    db.commit()
    return {"ok": True}

@app.post("/api/deals")
async def create_deal(req: CreateDealRequest, db: Session = Depends(get_db)):
    user_id = get_user_id_from_init(req.init_data)

    user = db.query(User).filter(User.telegram_id == user_id).first()
    if not user or not user.terms_accepted:
        raise HTTPException(status_code=403, detail="Terms not accepted")

    commission_amount = Decimal(str(req.amount)) * Decimal(str(COMMISSION)) / Decimal("100")
    expires = datetime.utcnow() + timedelta(hours=24)

    deal = Deal(
        creator_id=user_id,
        deal_type=req.deal_type,
        give_what=req.give_what,
        get_what=req.get_what,
        amount=req.amount,
        commission_percent=COMMISSION,
        commission_amount=commission_amount,
        notes=req.notes,
        status="created",
        expires_at=expires
    )
    db.add(deal)
    db.commit()
    db.refresh(deal)
    log_action(db, deal.id, "created", user_id)
    return {
        "deal_id": deal.id,
        "status": deal.status,
        "commission": float(commission_amount),
        "expires_at": expires.isoformat()
    }

@app.post("/api/deals/accept")
async def accept_deal(req: AcceptDealRequest, db: Session = Depends(get_db)):
    user_id = get_user_id_from_init(req.init_data)
    deal = db.query(Deal).filter(Deal.id == req.deal_id).first()
    if not deal or deal.status != "created":
        raise HTTPException(status_code=400, detail="Deal not available")
    if deal.expires_at and deal.expires_at < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Deal expired")
    if deal.creator_id == user_id:
        raise HTTPException(status_code=400, detail="Cannot accept own deal")

    deal.acceptor_id = user_id
    deal.status = "awaiting_deposit"
    db.commit()
    log_action(db, deal.id, "accepted", user_id)
    return {
        "ok": True,
        "status": deal.status,
        "instructions": get_deposit_instructions(deal)
    }

def get_deposit_instructions(deal: Deal) -> dict:
    if "gift" in (deal.deal_type or "").lower() or "подар" in (deal.give_what or "").lower():
        return {
            "type": "gift",
            "message": f"Отправьте подарок на Telegram-аккаунт @{OWNER_TG_USERNAME}",
            "telegram_username": OWNER_TG_USERNAME
        }
    else:
        return {
            "type": "crypto",
            "message": f"Отправьте {deal.amount} {OWNER_COIN} ({OWNER_NETWORK}). Bybit UID: {OWNER_BYBIT_UID}",
            "wallet": OWNER_WALLET,
            "network": OWNER_NETWORK,
            "coin": OWNER_COIN,
            "bybit_uid": OWNER_BYBIT_UID
        }

@app.post("/api/admin/confirm")
async def admin_confirm(req: AdminActionRequest, db: Session = Depends(get_db)):
    user_id = get_user_id_from_init(req.init_data)
    if user_id != OWNER_TG_ID:
        raise HTTPException(status_code=403, detail="Only owner")
    deal = db.query(Deal).filter(Deal.id == req.deal_id).first()
    if not deal or deal.status != "awaiting_deposit":
        raise HTTPException(status_code=400, detail="Cannot confirm")
    deal.status = "funded"
    db.commit()
    log_action(db, deal.id, "confirmed_by_owner", user_id)
    return {"ok": True, "status": "funded"}

@app.post("/api/admin/complete")
async def admin_complete(req: AdminActionRequest, db: Session = Depends(get_db)):
    user_id = get_user_id_from_init(req.init_data)
    if user_id != OWNER_TG_ID:
        raise HTTPException(status_code=403, detail="Only owner")
    deal = db.query(Deal).filter(Deal.id == req.deal_id).first()
    if not deal or deal.status != "funded":
        raise HTTPException(status_code=400, detail="Cannot complete")
    deal.status = "completed"
    db.commit()
    log_action(db, deal.id, "completed_by_owner", user_id)
    return {"ok": True, "status": "completed"}

@app.get("/api/deals")
async def list_deals(db: Session = Depends(get_db)):
    now = datetime.utcnow()
    deals = db.query(Deal).filter(
        Deal.status.in_(["created", "awaiting_deposit"]),
        (Deal.expires_at == None) | (Deal.expires_at > now)
    ).order_by(Deal.created_at.desc()).limit(50).all()
    return [{
        "id": d.id,
        "give": d.give_what,
        "get": d.get_what,
        "amount": float(d.amount),
        "commission": float(d.commission_amount),
        "type": d.deal_type,
        "status": d.status
    } for d in deals]

@app.get("/api/owner-info")
async def owner_info():
    return {
        "wallet": OWNER_WALLET,
        "network": OWNER_NETWORK,
        "coin": OWNER_COIN,
        "bybit_uid": OWNER_BYBIT_UID,
        "telegram_username": OWNER_TG_USERNAME
    }

@app.get("/health")
async def health():
    return {"status": "ok"}
