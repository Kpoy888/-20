from sqlalchemy import create_engine, Column, Integer, BigInteger, String, Numeric, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./deals.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    telegram_id = Column(BigInteger, primary_key=True)
    username = Column(String)
    first_name = Column(String)
    terms_accepted = Column(Integer, default=0)  # 0/1
    terms_accepted_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Deal(Base):
    __tablename__ = "deals"
    id = Column(Integer, primary_key=True, index=True)
    creator_id = Column(BigInteger)
    acceptor_id = Column(BigInteger, nullable=True)
    deal_type = Column(String)  # currency, gift, mixed
    give_what = Column(String)
    get_what = Column(String)
    amount = Column(Numeric)
    commission_percent = Column(Numeric, default=5.0)
    commission_amount = Column(Numeric, default=0)
    status = Column(String, default="created")  # created, awaiting_deposit, funded, completed, cancelled, disputed
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)

class DealLog(Base):
    __tablename__ = "deal_logs"
    id = Column(Integer, primary_key=True)
    deal_id = Column(Integer)
    action = Column(String)
    by_user = Column(BigInteger)
    created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)
